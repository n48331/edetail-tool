$(document).ready(function () {
	 	$(".s4_popupbtn1").click(function(){
            $(".popup_box_1").fadeIn();
            });
            $(".popup_box_1 .close").click(function(){
                $(".popup_box_1").fadeOut();
            });
        	$(".s4_popupbtn2").click(function(){
            $(".popup_box_2").fadeIn();
            });
            $(".popup_box_2 .close").click(function(){
                $(".popup_box_2").fadeOut();
            });
        	$(".s4_popupbtn3").click(function(){
            $(".popup_box_3").fadeIn();
            });
            $(".popup_box_3 .close").click(function(){
                $(".popup_box_3").fadeOut();
            });
        	$(".s4_popupbtn4").click(function(){
            $(".popup_box_4").fadeIn();
            });
            $(".popup_box_4 .close").click(function(){
                $(".popup_box_4").fadeOut();
            });
        	$(".s4_popupbtn5").click(function(){
            $(".popup_box_5").fadeIn();
            });
            $(".popup_box_5 .close").click(function(){
                $(".popup_box_5").fadeOut();
            });
        	$(".s4_popupbtn1").click(function(){
            $(".popup_box_1").fadeIn();
            });
            $(".popup_box_1 .close").click(function(){
                $(".popup_box_1").fadeOut();
            });
        	$(".s4_popupbtn2").click(function(){
            $(".popup_box_2").fadeIn();
            });
            $(".popup_box_2 .close").click(function(){
                $(".popup_box_2").fadeOut();
            });
        	$(".s4_popupbtn3").click(function(){
            $(".popup_box_3").fadeIn();
            });
            $(".popup_box_3 .close").click(function(){
                $(".popup_box_3").fadeOut();
            });
        	$(".s4_popupbtn4").click(function(){
            $(".popup_box_4").fadeIn();
            });
            $(".popup_box_4 .close").click(function(){
                $(".popup_box_4").fadeOut();
            });
        	$(".s4_popupbtn5").click(function(){
            $(".popup_box_5").fadeIn();
            });
            $(".popup_box_5 .close").click(function(){
                $(".popup_box_5").fadeOut();
            });
        	$(".s4_popupbtn1").click(function(){
            $(".popup_box_1").fadeIn();
            });
            $(".popup_box_1 .close").click(function(){
                $(".popup_box_1").fadeOut();
            });
        	$(".s4_popupbtn2").click(function(){
            $(".popup_box_2").fadeIn();
            });
            $(".popup_box_2 .close").click(function(){
                $(".popup_box_2").fadeOut();
            });
        	$(".s4_popupbtn3").click(function(){
            $(".popup_box_3").fadeIn();
            });
            $(".popup_box_3 .close").click(function(){
                $(".popup_box_3").fadeOut();
            });
        	$(".s4_popupbtn4").click(function(){
            $(".popup_box_4").fadeIn();
            });
            $(".popup_box_4 .close").click(function(){
                $(".popup_box_4").fadeOut();
            });
        	$(".s4_popupbtn5").click(function(){
            $(".popup_box_5").fadeIn();
            });
            $(".popup_box_5 .close").click(function(){
                $(".popup_box_5").fadeOut();
            });
        	$(".s4_popupbtn1").click(function(){
            $(".popup_box_1").fadeIn();
            });
            $(".popup_box_1 .close").click(function(){
                $(".popup_box_1").fadeOut();
            });
        	$(".s4_popupbtn2").click(function(){
            $(".popup_box_2").fadeIn();
            });
            $(".popup_box_2 .close").click(function(){
                $(".popup_box_2").fadeOut();
            });
        	$(".s4_popupbtn3").click(function(){
            $(".popup_box_3").fadeIn();
            });
            $(".popup_box_3 .close").click(function(){
                $(".popup_box_3").fadeOut();
            });
        	$(".s4_popupbtn4").click(function(){
            $(".popup_box_4").fadeIn();
            });
            $(".popup_box_4 .close").click(function(){
                $(".popup_box_4").fadeOut();
            });
        	$(".s4_popupbtn5").click(function(){
            $(".popup_box_5").fadeIn();
            });
            $(".popup_box_5 .close").click(function(){
                $(".popup_box_5").fadeOut();
            });
        	$(".s4_popupbtn1").click(function(){
            $(".popup_box_1").fadeIn();
            });
            $(".popup_box_1 .close").click(function(){
                $(".popup_box_1").fadeOut();
            });
        	$(".s4_popupbtn2").click(function(){
            $(".popup_box_2").fadeIn();
            });
            $(".popup_box_2 .close").click(function(){
                $(".popup_box_2").fadeOut();
            });
        	$(".s4_popupbtn3").click(function(){
            $(".popup_box_3").fadeIn();
            });
            $(".popup_box_3 .close").click(function(){
                $(".popup_box_3").fadeOut();
            });
        	$(".s4_popupbtn4").click(function(){
            $(".popup_box_4").fadeIn();
            });
            $(".popup_box_4 .close").click(function(){
                $(".popup_box_4").fadeOut();
            });
        	$(".s4_popupbtn5").click(function(){
            $(".popup_box_5").fadeIn();
            });
            $(".popup_box_5 .close").click(function(){
                $(".popup_box_5").fadeOut();
            });
        
    })
    