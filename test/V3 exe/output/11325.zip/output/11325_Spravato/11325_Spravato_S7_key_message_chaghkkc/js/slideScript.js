$(document).ready(function () {
	 	$(".s7_popupbtn1").click(function(){
            $(".popup_box_1").fadeIn();
            });
            $(".popup_box_1 .close").click(function(){
                $(".popup_box_1").fadeOut();
            });
        
    })
    