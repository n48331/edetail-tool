var config = {
	"project":"10935_SP",
	"slides": {
		"s1":{
		"name":"s1",
		"zipFile":"10935_SP_S1_Slide.zip"
		},
		"s2":{
		"name":"s2",
		"zipFile":"10935_SP_S2_Slide.zip"
		},
		"s3":{
		"name":"s3",
		"zipFile":"10935_SP_S3_Slide.zip"
		},
		"s4":{
		"name":"s4",
		"zipFile":"10935_SP_S4_Slide.zip"
		},
		"s5":{
		"name":"s5",
		"zipFile":"10935_SP_S5_Slide.zip"
		},
		"s6":{
		"name":"s6",
		"zipFile":"10935_SP_S6_Slide.zip"
		},
		"s7":{
		"name":"s7",
		"zipFile":"10935_SP_S7_Slide.zip"
		},
		"s8":{
		"name":"s8",
		"zipFile":"10935_SP_S8_Slide.zip"
		},
		"s9":{
		"name":"s9",
		"zipFile":"10935_SP_S9_Slide.zip"
		},
		"s10":{
		"name":"s10",
		"zipFile":"10935_SP_S10_Slide.zip"
		},
		"s11":{
		"name":"s11",
		"zipFile":"10935_SP_S11_Slide.zip"
		},
		"s12":{
		"name":"s12",
		"zipFile":"10935_SP_S12_Slide.zip"
		},
		"s13":{
		"name":"s13",
		"zipFile":"10935_SP_S13_Slide.zip"
		},
		"s14":{
		"name":"s14",
		"zipFile":"10935_SP_S14_Slide.zip"
		},
		"s15":{
		"name":"s15",
		"zipFile":"10935_SP_S15_Slide.zip"
		},
	},
	"coreflow":{
		/*First flow should have all the slides*/
		"f0": { 
			"content": ["s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9", "s10", "s11", "s12", "s13", "s14", "s15"],
			"name": "Flow 0"
		},
		"f5": { 
			"content": ["s5", "s1"],
			"name": "Flow 1"
		},
		"f7": { 
			"content": ["s7"],
			"name": "Flow 1"
		}
	},
	// "menu":{
	// 	/*First flow should have all the slides*/
	// 	"m0": {
	// 		"content": ["s3","s14","s1"],
	// 		"name": "Menu"
	// 	}

	// }
}