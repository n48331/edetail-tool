$(document).ready(function(){
  var iscroll;
  
  if (app.isTouchDevice()) { 
    touchEvent = 'touchend'; 
  } else { 
    touchEvent = 'click';
  }
 
  /* Anchor Slides Start */
  var getAnchorSlide = app.var.locstorage.anchor;
  if(getAnchorSlide){
  $(".close_icon").attr('data-slide',getAnchorSlide);
  }else{
    $(".close_icon").attr('data-slide','s1');
  }
  /* Anchor Slides stop */

  // $('#bottommenu2_s57').unbind().bind('touchstart tap', function(){
  //   $("#mainWrapper").css({
  //     'background': 'url("../shared/5450_TR_SharedResource/img/main2.jpg")',
  //     'background-size': 'cover'
  //   });
  // });
  // $('.bottommenu2').unbind().bind('tap', function(){
  //     app.var.slideTrackArr = (localStorage.getItem('slideTrackArr'))? JSON.parse(localStorage.getItem('slideTrackArr')): []
  //     app.var.slideTrackArr.push(app.var.currentSlide);
  //     localStorage.setItem('slideTrackArr',JSON.stringify(app.var.slideTrackArr));
  //     // alert(app.var.slideTrackArr);
  //     app.goTo(config.slides.s57.zipFile); 
  // });
  // $('.bottommenu1').unbind().bind('touchstart tap', function(){
  //   app.goTo(config.slides.s2.zipFile);  
  // });
  // $('.bottommenu2').unbind().bind('touchstart tap', function(){
  //   console.log("hhh")
  //   app.goTo(config.slides.s3.zipFile);    
  // });
  // $('.bottommenu3').unbind().bind('touchstart tap', function(){
  //   app.goTo(config.slides.s1.zipFile);    
  // });

  $(".smpcbtn").unbind().bind('touchstart tap', function(){
    document.location="../shared/10935_SP_SharedResource/pdf/Spravato-FullSmPC-23.08.2022-IA-015.pdf";
  });

  $(document).on(touchEvent, '.topmenu4', function(){
    $('#screen_popup').show();
  });
  $(document).on(touchEvent, '#screen_close', function(){
    $('#screen_popup').hide();
    return false;
  });
  $(document).on(touchEvent, '.topmenu2', function(){
    $('#screen_popup2').show();
  });
  $(document).on(touchEvent, '#screen_close2', function(){
    $('#screen_popup2').hide();
    return false;
  });
  $(document).on(touchEvent, '.topmenu3', function(){
    $('#screen_popup3').show();
	setTimeout(function() {
            if(iscroll != null){
                iscroll.scrollTo(0,0);
                iscroll.destroy();
                iscroll.wrapper.firstElementChild.setAttribute('style','')
                iscroll = null;
            }
                    if (iscroll == null) {
            iscroll = new IScroll('#scroll-content_wrapper', {
                interactiveScrollbars: true,
                bounce: false,
                momentum: false,
                scrollbars: true,
                scrollX: false,
                scrollY: true
            });
        }
        },50)
  });
  $(document).on(touchEvent, '#screen_close3', function(){
    $('#screen_popup3').hide();
	iscroll.scrollTo(0,0);
    iscroll.destroy();
    return false;
  });

// Next anf Previous

  $(document).on(touchEvent, '.rightArrow', function(){
    app.goNextSlide();
  });
  $(document).on(touchEvent, '.leftArrow', function(){
    app.goPrevSlide();
  });


});

// Play Video here
function openModalVideo(id) {
    setTimeout(function() {
        var identifier = id;
        console.log("opening modal: " + id);
        $('.modal').removeClass('visible');
        setTimeout(function(){
            $('.modal').removeClass('active');
        },300);
        setTimeout(function(){
            $('#modal-modal_'+ identifier).addClass('active');
            setTimeout(function(){
                $('#modal-modal_'+ identifier).addClass('visible');
            },0);
        }, 310);

        if(isEngage){ 
            $("video").hide();
            $(".video_bg").show();
            $(".video_bg").on(touchEvent, function() {
                closeModal(identifier);
            });
        } else {
            $("*[vidplayer]").on(touchEvent, function() {
                $('#neromuscular').get(0).play();
            });
            $('#neromuscular').on(touchEvent, function() {
                $('#neromuscular').get(0).pause();
                $(".video_bg").show();
                $(".video_bg").on(touchEvent, function() {
                    closeModal(identifier);
                });
            });
        }
    }, 50);
}
function closeModal(id) {
    var identifier = id;
    $('#modal-modal_'+ identifier).removeClass('visible');
    $('#modal-modal_'+ identifier + ' video').each(function () { this.load() });
    setTimeout(function(){
        $('#modal-modal_'+ identifier).removeClass('active');
    },300);
    $(".video_bg").css('display','none');
}
// Play Video here