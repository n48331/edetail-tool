$(document).ready(function () {

	/*$('.bottompopup').unbind().bind('touchstart tap', function () {
		$('#infopopup').show();
		$('#mainWrapper').addClass("not_to_swipe");
	});
	$('#infoclose').unbind().bind('touchstart tap', function () {
		$('#infopopup').hide();
		$('#mainWrapper').removeClass("not_to_swipe");
		return false;
	});*/
	
	// $(".slide6popupbtn1").unbind().bind("touchstart tap", function () {
	// 	$("#screen_popup1").show();
	// 	// $('#mainWrapper').addClass("not_to_swipe");
	// });
	// $("#screen_close1").unbind().bind("touchstart tap", function () {
	// 	$("#screen_popup1").hide();
	// 	// $('#mainWrapper').removeClass("not_to_swipe");
	// 	return false;
	// });
	$(document).on(touchEvent, '.slide6popupbtn1', function(){
    	$("#screen_popup1").show();
	});

	$(document).on(touchEvent, '#screen_close1', function(){
    	$("#screen_popup1").hide();
	});
})