$(document).ready(function () {

	/*$('.bottompopup').unbind().bind('touchstart tap', function () {
		$('#infopopup').show();
		$('#mainWrapper').addClass("not_to_swipe");
	});
	$('#infoclose').unbind().bind('touchstart tap', function () {
		$('#infopopup').hide();
		$('#mainWrapper').removeClass("not_to_swipe");
		return false;
	});*/
	
})