$(document).ready(function () {

	/*$('.bottompopup').unbind().bind('touchstart tap', function () {
		$('#infopopup').show();
		$('#mainWrapper').addClass("not_to_swipe");
	});
	$('#infoclose').unbind().bind('touchstart tap', function () {
		$('#infopopup').hide();
		$('#mainWrapper').removeClass("not_to_swipe");
		return false;
	});*/
	

	$(document).on(touchEvent, '.linkbtn1', function(){
    	$(".linkbtn1").show();
	});

	$(".linkbtn1").unbind().bind('touchstart tap', function(){
		// document.location="../shared/10935_SP_SharedResource/pdf/Spravato-FullSmPC-23.08.2022-IA-015.pdf";
		window.location="http://www.antoniocasella.eu/salute/Oxford_suicide_2012.pdf"
	  });

})