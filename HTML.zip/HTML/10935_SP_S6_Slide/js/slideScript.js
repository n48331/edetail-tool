$(document).ready(function () {

	/*$('.bottompopup').unbind().bind('touchstart tap', function () {
		$('#infopopup').show();
		$('#mainWrapper').addClass("not_to_swipe");
	});
	$('#infoclose').unbind().bind('touchstart tap', function () {
		$('#infopopup').hide();
		$('#mainWrapper').removeClass("not_to_swipe");
		return false;
	});*/

	$(document).on(touchEvent, '.slide6popupbtn1', function(){
    	$("#screen_popup1").show();
	});

	$(document).on(touchEvent, '#screen_close1', function(){
    	$("#screen_popup1").hide();
	});


	$(document).on(touchEvent, '.slide6popupbtn2', function(){
    	$("#screen_popup2").show();
	});

	$(document).on(touchEvent, '#screen_close2', function(){
    	$("#screen_popup2").hide();
	});


	$(document).on(touchEvent, '.slide6popupbtn3', function(){
    	$("#screen_popup3").show();
	});

	$(document).on(touchEvent, '#screen_close3', function(){
    	$("#screen_popup3").hide();
	});

	// $(".slide6popupbtn2").unbind().bind("touchstart tap", function () {
	// 	$("#screen_popup2").show();
	// 	// $('#mainWrapper').addClass("not_to_swipe");
	// });
	// $("#screen_close2").unbind().bind("touchstart tap", function () {
	// 	$("#screen_popup2").hide();
	// check this	// $('#mainWrapper').removeClass("not_to_swipe");
	// 	return false;
	// });

	// $(".slide6popupbtn3").unbind().bind("touchstart tap", function () {
	// 	$("#screen_popup3").show();
	// 	// $('#mainWrapper').addClass("not_to_swipe");
	// });
	// $("#screen_close3").unbind().bind("touchstart tap", function () {
	// 	$("#screen_popup3").hide();
	// 	// $('#mainWrapper').removeClass("not_to_swipe");
	// 	return false;
	// });
})