***Maintain this folder Structure***

main_folder/
├─ boiler_plate/
│  ├─ shared/
│  │  ├─ SharedResource/
│  │  │  ├─ common/
│  ├─ slide/
│  │  ├─ css/
│  │  ├─ img/
│  │  ├─ js/
├─ images/
├─ output/-(output folder is generated after first execution)
├─ data.xlsx
├─ eD-Tool_V1.4.exe



Instructions:
1.Copy all images to 'images' folder.
2.Set data in 'data.xlsx' with project name.
3.Provide popup if present.
4.Run the exe file and wait for output folder to generate.
5.After successful execution all files will present in output folder

