$(document).ready(function(){
  $(".s2_popup1").click(function(){
		$(".popup_box_1").show();
	});
	$(".popup_box_1 .close").click(function(){
		$(".popup_box_1").hide();
	});
	$(".s2_popup2").click(function(){
		$(".popup_box_2").show();
	});
	$(".popup_box_2 .close").click(function(){
		$(".popup_box_2").hide();
	});
});