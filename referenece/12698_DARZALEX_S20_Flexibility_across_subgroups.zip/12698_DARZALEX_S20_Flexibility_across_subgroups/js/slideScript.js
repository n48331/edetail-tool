$(document).ready(function(){
    $(".s20_popup1").click(function(){
          $(".popup_box_1").show();
      });
      $(".popup_box_1 .close").click(function(){
          $(".popup_box_1").hide();
      });

     
  });
    