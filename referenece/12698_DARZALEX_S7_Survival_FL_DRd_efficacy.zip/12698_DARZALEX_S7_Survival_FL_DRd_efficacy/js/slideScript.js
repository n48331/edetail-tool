$(document).ready(function(){
    $(".nextSlide").click(function(){
          $(".popup_box").show();
      });
      $(".popup_box .prevSlide").click(function(){
          $(".popup_box").hide();
      });

     
  });
    